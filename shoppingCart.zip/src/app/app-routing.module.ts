import { Placeholder } from '@angular/compiler/src/i18n/i18n_ast';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PlaceOrderComponent } from './modules/pages/place-order/place-order.component';
import { SignUpComponent } from './modules/pages/sign-up/sign-up.component';


const appRoutes: Routes = [
  { path: '', component: SignUpComponent },
  { path: 'place-order', component: PlaceOrderComponent },
];


@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
