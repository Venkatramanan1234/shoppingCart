import { Component, Input, OnInit } from '@angular/core';
import { PlaceOrderService } from './place-order.service';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.scss']
})
export class PlaceOrderComponent implements OnInit {
  @Input() userName: string;
public Categories;
  constructor(private placeOrderService: PlaceOrderService) {
    this.placeOrderService.getProducts()
    .subscribe((response: any) => {
      if (response) {
        this.Categories = response.Categories;
      }
    });
  }

  ngOnInit() {
 
  }

  public checkout() {
    const reqbody = {

    };
    this.placeOrderService.checkoutProducts(reqbody)
    .subscribe((resp: any) => {
      if (resp) {
       if (resp.code === '1') {
         alert('Order Submission Successful');
       } else if (resp.code === '0') {
         alert ('Order Submission Unsuccessful');
       }
      }

    },
    (error) => {
      console.log(error);
    });
  }



}
