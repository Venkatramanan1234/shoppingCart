(function(window) {
    window['CentralCreditServiceUrl'] = 'http://localhost:8080/centralcreditservice/v1/';
    window['systemIP'] = '10.121.49.100';
  })(this);
